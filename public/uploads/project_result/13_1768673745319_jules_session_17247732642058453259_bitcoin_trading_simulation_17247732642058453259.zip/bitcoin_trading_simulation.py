
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --- Simulation Parameters ---
# These parameters define the characteristics of the simulated Bitcoin price data.
initial_price = 60000  # Starting Bitcoin price in USD.
days = 60             # The total number of days to simulate.
volatility = 0.03      # The daily volatility of Bitcoin's price (e.g., 0.03 = 3%).
drift = 0.001          # The daily drift, or average daily return (e.g., 0.001 = 0.1%).

# --- Generate Simulated Bitcoin Price Data ---
# We use a geometric Brownian motion model to simulate the price series.
# This model is commonly used for financial time series.
np.random.seed(42)  # Set a seed for reproducibility of the random numbers.
# Generate daily returns from a normal distribution with the specified drift and volatility.
daily_returns = np.random.normal(drift, volatility, days)
# Create a list to store the daily prices, starting with the initial price.
prices = [initial_price]
# Generate the price for each day by applying the daily return to the previous day's price.
for r in daily_returns:
    prices.append(prices[-1] * (1 + r))

# Create a pandas DataFrame to store and analyze the price data.
df = pd.DataFrame({'Price': prices[1:]}) # Exclude the initial price from the main data.

# --- Calculate Moving Averages ---
# Moving averages are used to smooth out price data and identify trends.
df['MA7'] = df['Price'].rolling(window=7).mean()   # 7-day simple moving average.
df['MA30'] = df['Price'].rolling(window=30).mean() # 30-day simple moving average.

# --- Golden Cross Trading Algorithm ---
# This algorithm uses two moving averages to generate trading signals.
# A "Golden Cross" (buy signal) occurs when the short-term MA crosses above the long-term MA.
# A "Death Cross" (sell signal) occurs when the short-term MA crosses below the long-term MA.
portfolio = {'USD': 100000, 'BTC': 0} # Initial portfolio with 100,000 USD and 0 BTC.
log = []                             # A log to record all trading activities.
position = None                      # The current position ('BUY' or 'SELL').

# Iterate through the data starting from the second day to check for signals.
for i in range(1, len(df)):
    # Check for a Golden Cross (Buy Signal).
    # This occurs when the 7-day MA crosses above the 30-day MA.
    if df['MA7'].iloc[i] > df['MA30'].iloc[i] and df['MA7'].iloc[i-1] < df['MA30'].iloc[i-1] and position != 'BUY':
        # Execute the buy order.
        btc_to_buy = portfolio['USD'] / df['Price'].iloc[i]
        portfolio['BTC'] += btc_to_buy
        portfolio['USD'] = 0
        position = 'BUY'
        log.append(f"Day {i+1}: Golden Cross! Buying {btc_to_buy:.6f} BTC at ${df['Price'].iloc[i]:.2f}")

    # Check for a Death Cross (Sell Signal).
    # This occurs when the 7-day MA crosses below the 30-day MA.
    elif df['MA7'].iloc[i] < df['MA30'].iloc[i] and df['MA7'].iloc[i-1] > df['MA30'].iloc[i-1] and position != 'SELL':
        # Execute the sell order.
        usd_to_get = portfolio['BTC'] * df['Price'].iloc[i]
        portfolio['USD'] += usd_to_get
        portfolio['BTC'] = 0
        position = 'SELL'
        log.append(f"Day {i+1}: Death Cross! Selling all BTC for ${usd_to_get:.2f}")

# --- Print Daily Ledger ---
# Display the log of all trades made during the simulation.
print("--- Daily Trading Ledger ---")
for entry in log:
    print(entry)

# --- Final Portfolio Performance ---
# Calculate and display the final performance of the trading strategy.
final_portfolio_value = portfolio['USD'] + portfolio['BTC'] * df['Price'].iloc[-1]
initial_portfolio_value = 100000
performance = (final_portfolio_value - initial_portfolio_value) / initial_portfolio_value * 100

print("\n--- Final Portfolio Performance ---")
print(f"Initial Portfolio Value: ${initial_portfolio_value:.2f}")
print(f"Final Portfolio Value: ${final_portfolio_value:.2f}")
print(f"Performance: {performance:.2f}%")

# --- Plot the data ---
# Create a plot to visualize the Bitcoin price, moving averages, and trading signals.
plt.figure(figsize=(12, 6))
plt.plot(df['Price'], label='Price')
plt.plot(df['MA7'], label='7-Day MA')
plt.plot(df['MA30'], label='30-Day MA')
plt.title('Bitcoin Price Simulation with Golden Cross Strategy')
plt.xlabel('Days')
plt.ylabel('Price (USD)')
plt.legend()
plt.grid(True)
plt.savefig('btc_simulation.png')
print("\nPlot saved to btc_simulation.png")
